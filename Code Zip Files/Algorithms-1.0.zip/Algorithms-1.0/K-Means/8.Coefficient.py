# ==========================================================
# K-MEANS + COEFFICIENT OF VARIATION (ONE IMAGE)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Placement.csv"
n_clusters = 3

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

# Keep numeric columns only
X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

# Standardize for clustering
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==========================================================
# 🔹 3. APPLY K-MEANS
# ==========================================================
kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=20)
labels = kmeans.fit_predict(X_scaled)

# Add cluster labels to original (non-scaled) data
X_original = pd.DataFrame(X, columns=X.columns)
X_original["Cluster"] = labels

# ==========================================================
# 🔹 4. CALCULATE COEFFICIENT OF VARIATION (First Feature)
# ==========================================================
feature_name = X.columns[0]

cv_values = []

for c in range(n_clusters):
    cluster_data = X_original[X_original["Cluster"] == c][feature_name]
    mean = np.mean(cluster_data)
    std = np.std(cluster_data, ddof=1)

    if mean != 0:
        cv = std / mean
    else:
        cv = 0

    cv_values.append(cv)

# ==========================================================
# 🔹 5. PLOT SINGLE IMAGE
# ==========================================================
plt.figure()
plt.bar(range(n_clusters), cv_values)
plt.xlabel("Clusters")
plt.ylabel("Coefficient of Variation (CV)")
plt.title(f"Coefficient of Variation - {feature_name} (Placement Dataset)")
plt.xticks(range(n_clusters), [f"C{c}" for c in range(n_clusters)])
plt.tight_layout()

output_file = "Placement.jpg"
plt.savefig(output_file, format="jpg")
plt.close()

print(f"CV plot saved as: {output_file}")
