# ==========================================================
# FUZZY C-MEANS (FCM) + BOXPLOT VISUALIZATION
# (ONE IMAGE ONLY)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import skfuzzy as fuzz
from sklearn.preprocessing import StandardScaler
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Delivery.csv" #Change
n_clusters = 3
m = 2.0   # Fuzziness parameter

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

# Keep numeric columns only
X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

# Standardize
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ==========================================================
# 🔹 3. APPLY FCM
# ==========================================================
# FCM requires (features × samples)
cntr, u, _, _, _, _, _ = fuzz.cluster.cmeans(
    X_scaled.T,
    c=n_clusters,
    m=m,
    error=0.005,
    maxiter=1000,
    seed=42
)

# Convert fuzzy membership to crisp labels
labels = np.argmax(u, axis=0)

# Add cluster labels to original (non-scaled) data
X_original = pd.DataFrame(X, columns=X.columns)
X_original["Cluster"] = labels

# ==========================================================
# 🔹 4. GENERATE SINGLE BOXPLOT IMAGE
# ==========================================================
plt.figure(figsize=(8, 6))

# Choose first feature for boxplot
feature_name = X.columns[0]

data_to_plot = [
    X_original[X_original["Cluster"] == c][feature_name]
    for c in range(n_clusters)
]

plt.boxplot(data_to_plot)
plt.xlabel("Clusters")
plt.ylabel(feature_name)
plt.title(f"Boxplot of {feature_name} Across Clusters (Deliver Dataset)") #Chnage
plt.xticks(range(1, n_clusters + 1), [f"C{c}" for c in range(n_clusters)])
plt.tight_layout()

output_file = "Delivery.jpg" #Change
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Boxplot saved as: {output_file}")
