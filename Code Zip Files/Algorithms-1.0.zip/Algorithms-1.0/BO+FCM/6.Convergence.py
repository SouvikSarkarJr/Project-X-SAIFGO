# ==========================================================
# BILLIARDS OPTIMIZATION (BO) + FCM + CONVERGENCE CURVE
# (ONE IMAGE OUTPUT)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import cdist
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Bank.csv" # Change
n_clusters = 3
m = 2.0
epsilon = 1e-5

# BO parameters
n_agents = 20
bo_iterations = 30

# FCM parameters
fcm_max_iter = 50

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

scaler = StandardScaler()
X = scaler.fit_transform(X)

n_samples, n_features = X.shape

# ==========================================================
# 🔹 3. HELPER FUNCTIONS
# ==========================================================

def compute_membership(X, centroids, m):
    dist = cdist(X, centroids) + 1e-10
    power = 2 / (m - 1)
    temp = dist ** power
    denominator = temp[:, :, None] / temp[:, None, :]
    u = 1 / np.sum(denominator, axis=2)
    return u

def objective_function(X, U, centroids, m):
    dist = cdist(X, centroids)
    return np.sum((U ** m) * (dist ** 2))

def fitness(centroids):
    U = compute_membership(X, centroids, m)
    return objective_function(X, U, centroids, m)

# ==========================================================
# 🔹 4. BILLIARDS OPTIMIZATION (BO) PHASE
# ==========================================================

agents = np.random.uniform(
    low=X.min(axis=0),
    high=X.max(axis=0),
    size=(n_agents, n_clusters, n_features)
)

fitness_scores = np.array([fitness(a) for a in agents])
best_idx = np.argmin(fitness_scores)
best_solution = agents[best_idx].copy()

bo_history = []

for iteration in range(bo_iterations):

    for i in range(n_agents):

        direction = np.random.randn(n_clusters, n_features)
        velocity = np.random.rand()

        new_position = agents[i] + velocity * direction

        lower = X.min(axis=0)
        upper = X.max(axis=0)

        # Reflection boundary handling
        new_position = np.where(new_position < lower,
                                lower + (lower - new_position),
                                new_position)

        new_position = np.where(new_position > upper,
                                upper - (new_position - upper),
                                new_position)

        new_position = np.clip(new_position, lower, upper)

        new_score = fitness(new_position)

        if new_score < fitness_scores[i]:
            agents[i] = new_position
            fitness_scores[i] = new_score

    best_idx = np.argmin(fitness_scores)
    best_solution = agents[best_idx].copy()

    best_score = fitness_scores[best_idx]
    bo_history.append(best_score)

# ==========================================================
# 🔹 5. FCM REFINEMENT PHASE (Manual)
# ==========================================================

U = compute_membership(X, best_solution, m)
fcm_history = []

for iteration in range(fcm_max_iter):

    U_m = U ** m
    centroids = (U_m.T @ X) / np.sum(U_m.T, axis=1, keepdims=True)

    dist = cdist(X, centroids) + 1e-10
    J = np.sum((U ** m) * (dist ** 2))
    fcm_history.append(J)

    new_U = compute_membership(X, centroids, m)

    if np.linalg.norm(new_U - U) < epsilon:
        break

    U = new_U

# ==========================================================
# 🔹 6. PLOT COMBINED CONVERGENCE CURVE
# ==========================================================

plt.figure()

# BO phase
plt.plot(range(1, len(bo_history) + 1),
         bo_history,
         label="BO Phase")

# FCM phase shifted
fcm_x = range(len(bo_history) + 1,
              len(bo_history) + len(fcm_history) + 1)

plt.plot(fcm_x,
         fcm_history,
         label="FCM Refinement Phase")

plt.xlabel("Iteration")
plt.ylabel("Objective Function (Jm)")
plt.title("BO + FCM Convergence Curve (Bank Dataset)") # Chnage
plt.legend()
plt.tight_layout()

output_file = "Bank_BO_FCM_Convergence.jpg" # Change
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Convergence curve saved as: {output_file}")
