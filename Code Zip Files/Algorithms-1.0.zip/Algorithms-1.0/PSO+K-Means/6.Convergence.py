# ==========================================================
# PSO + K-MEANS + CONVERGENCE CURVE ANALYSIS
# (ONE IMAGE OUTPUT)
# ==========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from scipy.spatial.distance import cdist
import os

# ==========================================================
# 🔹 1. DATASET PATH
# ==========================================================
file_path = "/Users/souvik/Documents/Project-II/Data-sets/Placement.csv"  # Change
n_clusters = 3
max_iter = 50

# PSO parameters
n_particles = 20
pso_iterations = 30
w = 0.7
c1 = 1.5
c2 = 1.5

# ==========================================================
# 🔹 2. LOAD DATA
# ==========================================================
if not os.path.exists(file_path):
    raise FileNotFoundError("Dataset not found.")

df = pd.read_csv(file_path)

X = df.select_dtypes(include=[np.number])
X = X.drop(columns=["Id", "ID", "id"], errors="ignore")

if X.shape[1] == 0:
    raise ValueError("Dataset must contain numeric columns.")

scaler = StandardScaler()
X = scaler.fit_transform(X)

n_samples, n_features = X.shape

# ==========================================================
# 🔹 3. K-MEANS FUNCTION
# ==========================================================

def kmeans_from_centroids(X, centroids, max_iter=100):
    inertia_history = []

    for _ in range(max_iter):
        distances = cdist(X, centroids)
        labels = np.argmin(distances, axis=1)

        new_centroids = np.array([
            X[labels == k].mean(axis=0) if np.any(labels == k)
            else centroids[k]
            for k in range(n_clusters)
        ])

        inertia = np.sum((distances[np.arange(n_samples), labels]) ** 2)
        inertia_history.append(inertia)

        if np.allclose(new_centroids, centroids):
            break

        centroids = new_centroids

    return centroids, labels, inertia_history

# ==========================================================
# 🔹 4. FITNESS FUNCTION (SSE)
# ==========================================================

def fitness(centroids):
    _, _, inertia_hist = kmeans_from_centroids(X, centroids, max_iter=20)
    return inertia_hist[-1]

# ==========================================================
# 🔹 5. PARTICLE SWARM OPTIMIZATION PHASE
# ==========================================================

particles = np.random.uniform(
    low=X.min(axis=0),
    high=X.max(axis=0),
    size=(n_particles, n_clusters, n_features)
)

velocities = np.zeros_like(particles)

personal_best = particles.copy()
personal_best_scores = np.array([fitness(p) for p in particles])

global_best_index = np.argmin(personal_best_scores)
global_best = personal_best[global_best_index].copy()

pso_history = []

for iteration in range(pso_iterations):

    pso_history.append(np.min(personal_best_scores))

    for i in range(n_particles):

        r1 = np.random.rand()
        r2 = np.random.rand()

        velocities[i] = (
            w * velocities[i]
            + c1 * r1 * (personal_best[i] - particles[i])
            + c2 * r2 * (global_best - particles[i])
        )

        particles[i] += velocities[i]

        score = fitness(particles[i])

        if score < personal_best_scores[i]:
            personal_best[i] = particles[i].copy()
            personal_best_scores[i] = score

    global_best_index = np.argmin(personal_best_scores)
    global_best = personal_best[global_best_index].copy()

    print(f"Iteration {iteration+1}/{pso_iterations} - Best SSE: {personal_best_scores[global_best_index]:.6f}")

# ==========================================================
# 🔹 6. FINAL K-MEANS REFINEMENT
# ==========================================================

final_centroids, labels, kmeans_history = kmeans_from_centroids(
    X, global_best, max_iter=max_iter
)

# ==========================================================
# 🔹 7. PLOT COMBINED CONVERGENCE CURVE
# ==========================================================

plt.figure()

# PSO phase
plt.plot(range(1, len(pso_history) + 1),
         pso_history,
         label="PSO Phase")

# K-Means refinement phase
kmeans_x = range(len(pso_history) + 1,
                 len(pso_history) + len(kmeans_history) + 1)

plt.plot(kmeans_x,
         kmeans_history,
         label="K-Means Refinement Phase")

plt.xlabel("Iteration")
plt.ylabel("Inertia (SSE)")
plt.title("PSO + K-Means Convergence Curve (Placement Dataset)") #Change
plt.legend()
plt.tight_layout()

output_file = "Placement_PSO_KMeans_Convergence.jpg"  # Change
plt.savefig(output_file, format="jpg")
plt.close()

print(f"Convergence curve saved as: {output_file}")
