import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from tqdm import tqdm

# -----------------------------
# LOAD + PREPROCESS DATA
# -----------------------------
def load_and_preprocess(file_path):
    df = pd.read_csv(file_path)

    num_cols = df.select_dtypes(include=[np.number]).columns
    cat_cols = df.select_dtypes(exclude=[np.number]).columns

    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown='ignore'), cat_cols)
    ])

    X = preprocessor.fit_transform(df)

    if hasattr(X, "toarray"):
        X = X.toarray()

    return X


# -----------------------------
# VALIDITY INDICES
# -----------------------------
def davies_bouldin_index(X, labels, centers):
    k = len(centers)
    clusters = [X[labels == i] for i in range(k)]

    S = np.array([
        np.mean(cdist(cluster, [centers[i]])) if len(cluster) > 0 else 0
        for i, cluster in enumerate(clusters)
    ])

    M = cdist(centers, centers)
    np.fill_diagonal(M, np.inf)

    R = (S[:, None] + S[None, :]) / M
    return np.mean(np.max(R, axis=1))


def dunn_index(X, labels):
    clusters = [X[labels == i] for i in np.unique(labels)]

    inter = np.inf
    intra = 0

    for i in range(len(clusters)):
        if len(clusters[i]) > 1:
            intra = max(intra, np.max(cdist(clusters[i], clusters[i])))

        for j in range(i + 1, len(clusters)):
            if len(clusters[i]) > 0 and len(clusters[j]) > 0:
                inter = min(inter, np.min(cdist(clusters[i], clusters[j])))

    return inter / intra if intra != 0 else 0


def xie_beni_index(X, labels, centers):
    n = len(X)
    dist = cdist(X, centers)
    min_dist = np.min(dist, axis=1)

    numerator = np.sum(min_dist ** 2)

    center_dist = cdist(centers, centers)
    np.fill_diagonal(center_dist, np.inf)
    denominator = n * (np.min(center_dist) ** 2)

    return numerator / denominator


# -----------------------------
# FAST METAOOD (DE)
# -----------------------------
class MetaOOD_DE:
    def __init__(self, n_clusters=3, pop_size=8, max_iter=20):
        self.k = n_clusters
        self.pop_size = pop_size
        self.max_iter = max_iter

    def initialize_population(self, X):
        min_vals, max_vals = X.min(axis=0), X.max(axis=0)
        return np.random.uniform(min_vals, max_vals,
                                 (self.pop_size, self.k, X.shape[1]))

    def fitness(self, X, centers):
        dist = cdist(X, centers)
        compactness = np.sum(np.min(dist, axis=1))

        center_dist = cdist(centers, centers)
        np.fill_diagonal(center_dist, np.inf)
        separation = np.min(center_dist)

        return compactness - separation

    def optimize(self, X):
        pop = self.initialize_population(X)
        fitness_vals = np.array([self.fitness(X, p) for p in pop])

        F, CR = 0.5, 0.7

        for gen in tqdm(range(self.max_iter), desc="MetaOOD Optimization"):
            for i in range(self.pop_size):
                idxs = [idx for idx in range(self.pop_size) if idx != i]
                a, b, c = pop[np.random.choice(idxs, 3, replace=False)]

                mutant = a + F * (b - c)
                cross = np.random.rand(*mutant.shape) < CR
                trial = np.where(cross, mutant, pop[i])

                trial_fit = self.fitness(X, trial)

                if trial_fit < fitness_vals[i]:
                    pop[i] = trial
                    fitness_vals[i] = trial_fit

            print(f"Iteration {gen+1} | Best Fitness: {np.min(fitness_vals):.4f}")

        best = pop[np.argmin(fitness_vals)]
        return best


# -----------------------------
# HYBRID MODEL
# -----------------------------
class Hybrid_MetaOOD_KMeans:
    def __init__(self, n_clusters=3):
        self.k = n_clusters

    def fit(self, X):
        meta = MetaOOD_DE(n_clusters=self.k)
        init_centers = meta.optimize(X)

        kmeans = KMeans(
            n_clusters=self.k,
            init=init_centers,
            n_init=1,
            max_iter=300,
            random_state=42
        )

        labels = kmeans.fit_predict(X)

        self.labels = labels
        self.centers = kmeans.cluster_centers_

        return labels, self.centers


# -----------------------------
# MAIN EXECUTION
# -----------------------------
if __name__ == "__main__":
    file_path = "/Users/souviksarkarjr./Downloads/IFGO/Dataset/Wave.csv"

    print("Loading and preprocessing data...")
    X = load_and_preprocess(file_path)

    print("Running MetaOOD + KMeans...")
    model = Hybrid_MetaOOD_KMeans(n_clusters=3)
    labels, centers = model.fit(X)

    print("\nCalculating validation metrics...")

    sil = silhouette_score(X, labels)
    db = davies_bouldin_index(X, labels, centers)
    dunn = dunn_index(X, labels)
    xb = xie_beni_index(X, labels, centers)
    ch = calinski_harabasz_score(X, labels)

    print("\nFinal Results:")
    print(f"Silhouette Score      : {sil:.4f}")
    print(f"Davies-Bouldin Index : {db:.4f}")
    print(f"Dunn Index           : {dunn:.4f}")
    print(f"Xie-Beni Index       : {xb:.4f}")
    print(f"Calinski-Harabasz    : {ch:.4f}")